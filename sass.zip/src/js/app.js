import * as allFunctions from "./modules/functions.js";

allFunctions.isWebp();



